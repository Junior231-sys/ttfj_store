// data/products.ts
export type Product = {
  id: string;
  name: string;
  priceEUR: number;
  priceXAF: number;
  description: string;
  image?: string;
  category?: string;
};

export const products: Product[] = [
  {
    id: "prod_tshirt_001",
    name: "T-shirt Urban",
    priceEUR: 15.0,
    priceXAF: 10000,
    description: "T-shirt 100% coton — coupe régulière.",
    image: "/images/tshirt.jpg",
    category: "vêtements",
  },
  {
    id: "prod_shoes_001",
    name: "Baskets Runner",
    priceEUR: 45.0,
    priceXAF: 30000,
    description: "Chaussures confortables pour tous les jours.",
    image: "/images/shoes.jpg",
    category: "chaussures",
  },
  {
    id: "prod_hat_001",
    name: "Casquette Classic",
    priceEUR: 8.5,
    priceXAF: 5000,
    description: "Casquette réglable, logo minimal.",
    image: "/images/hat.jpg",
    category: "chapeaux",
  }
];
