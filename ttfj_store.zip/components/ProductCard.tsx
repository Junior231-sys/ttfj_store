import Link from "next/link";
import { Product } from "../data/products";

export default function ProductCard(p: Product) {
  return (
    <div className="border rounded p-4 shadow-sm hover:shadow-lg transition">
      <img src={p.image || "/images/placeholder.png"} alt={p.name} className="w-full h-48 object-cover mb-3 rounded" />
      <h3 className="font-semibold text-lg">{p.name}</h3>
      <p className="text-gray-600">{p.priceEUR.toFixed(2)} € — {p.priceXAF.toLocaleString()} XAF</p>
      <div className="mt-3">
        <Link href={`/product/${p.id}`}>
          <a className="inline-block px-3 py-1 bg-black text-white rounded">Voir</a>
        </Link>
      </div>
    </div>
  );
}
