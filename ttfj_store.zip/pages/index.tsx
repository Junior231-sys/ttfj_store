import Head from "next/head";
import ProductCard from "../components/ProductCard";
import { products } from "../data/products";
import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return (
    <div>
      <Head>
        <title>TTFJ Store - Mode & Accessoires</title>
      </Head>

      <header className="flex items-center justify-between p-4 bg-black text-white">
        <div className="flex items-center space-x-3">
          <Image src="/images/logo.png" alt="TTFJ Store" width={80} height={80} />
          <h1 className="text-2xl font-bold text-yellow-400">TTFJ Store</h1>
        </div>
        <nav className="space-x-6 text-yellow-300">
          <Link href="/">Accueil</Link>
          <Link href="/suivi">Suivi</Link>
          <Link href="/admin/orders">Admin</Link>
        </nav>
      </header>

      <main className="container mx-auto p-6">
        <header className="mb-6">
          <h2 className="text-3xl font-bold">Ma boutique — Mode & Accessoires</h2>
          <p className="text-gray-600">Vêtements, chaussures, chapeaux — paiement par carte et Mobile Money</p>
        </header>

        <section className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {products.map(p => <ProductCard key={p.id} {...p} />)}
        </section>
      </main>
    </div>
  );
}
