import type { NextApiRequest, NextApiResponse } from "next";
import fs from "fs";
import path from "path";

const ordersFile = path.join(process.cwd(), "data", "orders.json");

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  const orders = JSON.parse(fs.readFileSync(ordersFile, "utf8"));
  res.status(200).json(orders);
}
