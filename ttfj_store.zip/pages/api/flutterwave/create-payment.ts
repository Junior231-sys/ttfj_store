import type { NextApiRequest, NextApiResponse } from "next";
import { products } from "../../../data/products";

type Body = {
  id: string;
  currency?: string;
  customer_email?: string;
  customer_phone?: string;
  customer_name?: string;
  tx_ref?: string;
  redirect_url?: string;
};

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).end();

  const body: Body = req.body;
  const FLW_SECRET = process.env.FLW_SECRET_KEY;
  if (!FLW_SECRET) return res.status(500).json({ error: "Missing Flutterwave secret key" });

  const product = products.find(p => p.id === body.id);
  if (!product) return res.status(400).json({ error: "Produit introuvable" });

  const tx_ref = body.tx_ref || `tx_${Date.now()}`;
  const redirect_url = body.redirect_url || `${process.env.NEXT_PUBLIC_URL}/success`;

  const amount = product.priceXAF;

  const payload = {
    tx_ref,
    amount,
    currency: body.currency || "XAF",
    redirect_url,
    customer: {
      email: body.customer_email || "client@example.com",
      phonenumber: body.customer_phone || "690000000",
      name: body.customer_name || "Client",
    },
    meta: {
      product_id: product.id,
      product_name: product.name
    },
    payment_options: "mobilemoney,card",
  };

  try {
    const r = await fetch("https://api.flutterwave.com/v3/payments", {
      method: "POST",
      headers: {
        "Content-Type":"application/json",
        Authorization: `Bearer ${FLW_SECRET}`
      },
      body: JSON.stringify(payload)
    });

    const data = await r.json();
    if (!r.ok) {
      console.error("Flutterwave init error:", data);
      return res.status(500).json({ error: "Flutterwave init error", details: data });
    }

    return res.status(200).json({ link: data.data.link, tx_ref });
  } catch (err) {
    console.error("Flutterwave error:", err);
    return res.status(500).json({ error: "Internal error", details: String(err) });
  }
}
