import type { NextApiRequest, NextApiResponse } from "next";
import fs from "fs";
import path from "path";
import { sendOrderEmail } from "../../../lib/sendEmail";

const ordersFile = path.join(process.cwd(), "data", "orders.json");
const FLW_SECRET_KEY = process.env.FLW_SECRET_KEY || "";

export const config = {
  api: {
    bodyParser: true,
  },
};

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).end();

  const signature = req.headers["verif-hash"];
  if (!signature || signature !== FLW_SECRET_KEY) {
    console.error("❌ Signature Flutterwave invalide");
    return res.status(401).send("Invalid signature");
  }

  const event = req.body;

  if (event.event === "charge.completed" && event.data.status === "successful") {
    const data = event.data;

    const order = {
      id: data.tx_ref,
      provider: "flutterwave",
      amount: data.amount,
      currency: data.currency,
      customer_email: data.customer.email,
      customer_phone: data.customer.phone_number,
      status: "paid",
      date: new Date().toISOString(),
    };

    const orders = JSON.parse(fs.readFileSync(ordersFile, "utf8"));
    orders.push(order);
    fs.writeFileSync(ordersFile, JSON.stringify(orders, null, 2));

    console.log("✅ Commande Flutterwave enregistrée :", order);

    if (data.customer.email) {
      await sendOrderEmail({
        to: data.customer.email,
        order,
      });
    }
  }

  res.status(200).json({ received: true });
}
