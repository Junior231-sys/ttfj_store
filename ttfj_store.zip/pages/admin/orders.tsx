import { useEffect, useState } from "react";
import Head from "next/head";

type Order = {
  id: string;
  provider: string;
  amount: number;
  currency: string;
  customer_email?: string;
  customer_phone?: string;
  status: string;
  date: string;
};

export default function OrdersAdminPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/orders")
      .then((r) => r.json())
      .then((data) => {
        setOrders(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  return (
    <div className="container mx-auto p-8">
      <Head>
        <title>Commandes — Admin</title>
      </Head>

      <h1 className="text-3xl font-bold mb-6">📦 Liste des commandes</h1>

      {loading && <p>Chargement des données...</p>}

      {!loading && orders.length === 0 && (
        <p className="text-gray-600">Aucune commande enregistrée pour le moment.</p>
      )}

      {!loading && orders.length > 0 && (
        <div className="overflow-x-auto">
          <table className="min-w-full border border-gray-300">
            <thead className="bg-gray-100">
              <tr>
                <th className="py-2 px-4 border">ID</th>
                <th className="py-2 px-4 border">Source</th>
                <th className="py-2 px-4 border">Montant</th>
                <th className="py-2 px-4 border">Client</th>
                <th className="py-2 px-4 border">Statut</th>
                <th className="py-2 px-4 border">Date</th>
              </tr>
            </thead>
            <tbody>
              {orders
                .sort(
                  (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
                )
                .map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50">
                    <td className="py-2 px-4 border text-sm">{order.id}</td>
                    <td className="py-2 px-4 border capitalize">
                      {order.provider}
                    </td>
                    <td className="py-2 px-4 border font-semibold">
                      {order.amount} {order.currency.toUpperCase()}
                    </td>
                    <td className="py-2 px-4 border text-sm">
                      {order.customer_email || order.customer_phone || "—"}
                    </td>
                    <td className="py-2 px-4 border">
                      <span
                        className={`px-2 py-1 rounded text-sm ${
                          order.status === "paid"
                            ? "bg-green-100 text-green-700"
                            : "bg-red-100 text-red-700"
                        }`}
                      >
                        {order.status}
                      </span>
                    </td>
                    <td className="py-2 px-4 border text-sm">
                      {new Date(order.date).toLocaleString()}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
